use std::alloc::{GlobalAlloc, Layout, System};
use std::hint::black_box;
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use std::time::Instant;

use burn_backend::{TensorData, ops::ConvTransposeOptions};
use burn_flex::{FlexTensor, ops::conv_transpose::conv_transpose3d_f32};

struct Alloc;
static CURRENT: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
fn allocated(n: usize) {
    let size = CURRENT.fetch_add(n, Relaxed) + n;
    PEAK.fetch_max(size, Relaxed);
}
unsafe impl GlobalAlloc for Alloc {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() {
            allocated(layout.size());
        }
        p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(layout) };
        if !p.is_null() {
            allocated(layout.size());
        }
        p
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) {
        CURRENT.fetch_sub(layout.size(), Relaxed);
        unsafe {
            System.dealloc(p, layout);
        }
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, new: usize) -> *mut u8 {
        let p = unsafe { System.realloc(p, layout, new) };
        if !p.is_null() {
            CURRENT.fetch_sub(layout.size(), Relaxed);
            allocated(new);
        }
        p
    }
}
#[global_allocator]
static ALLOC: Alloc = Alloc;

use burn_flex::ops::conv_transpose::{
    CHANNEL_BALANCED_TASKS, CHANNEL_GROUP_MODE, CHANNEL_MIN_WORK,
};

struct Case {
    name: String,
    x: [usize; 5],
    co: usize,
    kernel: [usize; 3],
    stride: [usize; 3],
    pad: [usize; 3],
    groups: usize,
}
#[derive(Clone, Copy)]
struct Policy {
    name: &'static str,
    minimum: usize,
    group_mode: usize,
    balanced: bool,
}
fn data(shape: [usize; 5], seed: u32) -> FlexTensor {
    let mut state = seed;
    let values: Vec<f32> = (0..shape.iter().product())
        .map(|_| {
            state ^= state << 13;
            state ^= state >> 17;
            state ^= state << 5;
            (state % 201) as f32 / 100.0 - 1.0
        })
        .collect();
    FlexTensor::from_data(TensorData::new(values, shape))
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    for co in [2, 8, 32, 64] {
        for work in [8192, 16384, 32768, 65536, 131072, 262144, 524288] {
            cases.push(Case {
                name: format!("threshold_1d_co{co}_work{work}"),
                x: [1, 16, 1, 1, work / (co * 8)],
                co,
                kernel: [1, 1, 8],
                stride: [1, 1, 2],
                pad: [0, 0, 3],
                groups: 1,
            });
        }
    }
    for co in [8, 32] {
        for side in [4, 7, 8, 11, 14, 16, 24, 32] {
            cases.push(Case {
                name: format!("threshold_2d_co{co}_side{side}"),
                x: [1, 32, 1, side, side],
                co,
                kernel: [1, 4, 4],
                stride: [1, 2, 2],
                pad: [0, 1, 1],
                groups: 1,
            });
        }
    }
    for (side, ci) in [(7, 64), (14, 128)] {
        cases.push(Case {
            name: format!("threshold_2d_co64_side{side}"),
            x: [1, ci, 1, side, side],
            co: 64,
            kernel: [1, 4, 4],
            stride: [1, 2, 2],
            pad: [0, 1, 1],
            groups: 1,
        });
    }
    for side in [3, 4, 6, 8, 12] {
        cases.push(Case {
            name: format!("threshold_3d_side{side}"),
            x: [1, 8, side, side, side],
            co: 8,
            kernel: [3; 3],
            stride: [2; 3],
            pad: [1; 3],
            groups: 1,
        });
    }
    for groups in [2, 3, 4, 5, 7, 8, 9, 16] {
        for length in [512, 2048, 8192] {
            cases.push(Case {
                name: format!("groups_g{groups}_l{length}"),
                x: [1, 4 * groups, 1, 1, length],
                co: 8,
                kernel: [1, 1, 16],
                stride: [1, 1, 2],
                pad: [0, 0, 7],
                groups,
            });
        }
    }
    for batch in [4, 5, 8] {
        cases.push(Case {
            name: format!("groups_batch{batch}_l2048"),
            x: [batch, 4, 1, 1, 2048],
            co: 8,
            kernel: [1, 1, 16],
            stride: [1, 1, 2],
            pad: [0, 0, 7],
            groups: 1,
        });
    }
    cases
}
fn measure() {
    let args: Vec<_> = std::env::args().collect();
    let filter = args.get(1).map(String::as_str).unwrap_or("");
    let rounds: usize = args.get(2).map(|s| s.parse().unwrap()).unwrap_or(7);
    let current = Policy {
        name: "current",
        minimum: 262144,
        group_mode: 0,
        balanced: false,
    };
    let thresholds = [
        current,
        Policy {
            name: "same_control",
            ..current
        },
        Policy {
            name: "min128k",
            minimum: 131072,
            ..current
        },
        Policy {
            name: "min64k",
            minimum: 65536,
            ..current
        },
        Policy {
            name: "balanced256k",
            balanced: true,
            ..current
        },
        Policy {
            name: "balanced128k",
            minimum: 131072,
            balanced: true,
            ..current
        },
        Policy {
            name: "balanced64k",
            minimum: 65536,
            balanced: true,
            ..current
        },
    ];
    let groups = [
        current,
        Policy {
            name: "same_control",
            ..current
        },
        Policy {
            name: "actual256k",
            group_mode: 2,
            ..current
        },
        Policy {
            name: "balanced256k",
            balanced: true,
            ..current
        },
        Policy {
            name: "balanced_actual256k",
            group_mode: 2,
            balanced: true,
            ..current
        },
        Policy {
            name: "balanced_actual128k",
            minimum: 131072,
            group_mode: 2,
            balanced: true,
            ..current
        },
        Policy {
            name: "balanced_actual64k",
            minimum: 65536,
            group_mode: 2,
            balanced: true,
            ..current
        },
    ];
    for case in cases()
        .into_iter()
        .filter(|c| filter.split(',').any(|f| c.name.contains(f)))
    {
        let policies = if case.name.starts_with("groups") {
            &groups
        } else {
            &thresholds
        };
        let x = data(case.x, 12345);
        let [kd, kh, kw] = case.kernel;
        let w = data([case.x[1], case.co, kd, kh, kw], 67890);
        let options = ConvTransposeOptions::new(case.stride, case.pad, [0; 3], [1; 3], case.groups);
        let run = || conv_transpose3d_f32(x.clone(), w.clone(), None, &options);
        let set_policy = |p: Policy| {
            CHANNEL_MIN_WORK.store(p.minimum, Relaxed);
            CHANNEL_GROUP_MODE.store(p.group_mode, Relaxed);
            CHANNEL_BALANCED_TASKS.store(p.balanced, Relaxed);
        };
        set_policy(current);
        let expected = run();
        let mut peaks = Vec::new();
        for &policy in policies {
            set_policy(policy);
            for _ in 0..3 {
                drop(black_box(run()));
            }
            let initial = CURRENT.load(Relaxed);
            PEAK.store(initial, Relaxed);
            let actual = run();
            peaks.push(PEAK.load(Relaxed).saturating_sub(initial));
            assert_eq!(expected.bytes().len(), actual.bytes().len());
            assert!(
                expected
                    .storage::<f32>()
                    .iter()
                    .zip(actual.storage::<f32>())
                    .all(|(a, b)| a.to_bits() == b.to_bits()),
                "{} / {}",
                case.name,
                policy.name
            );
        }
        set_policy(current);
        let start = Instant::now();
        drop(black_box(run()));
        let duration = start.elapsed().as_secs_f64();
        let iterations = (0.01 / duration).ceil().clamp(2.0, 80.0) as usize;
        let mut samples = vec![Vec::new(); policies.len()];
        for round in 0..rounds {
            // Rotate and reverse the policy order to reduce time drift.
            for step in 0..policies.len() {
                let index = if round % 2 == 0 {
                    (step + round / 2) % policies.len()
                } else {
                    (policies.len() - 1 - step + round / 2) % policies.len()
                };
                set_policy(policies[index]);
                drop(black_box(run()));
                let mut times = Vec::with_capacity(iterations);
                let initial = CURRENT.load(Relaxed);
                PEAK.store(initial, Relaxed);
                for _ in 0..iterations {
                    let start = Instant::now();
                    let output = black_box(run());
                    times.push(start.elapsed().as_secs_f64() * 1000.0);
                    drop(output);
                }
                peaks[index] = peaks[index].max(PEAK.load(Relaxed).saturating_sub(initial));
                times.sort_by(f64::total_cmp);
                samples[index].push(times[times.len() / 2]);
            }
        }
        let column_elements = case.co * kd * kh * kw * case.x[2..].iter().product::<usize>();
        for (i, policy) in policies.iter().enumerate() {
            println!(
                "{{\"case\":\"{}\",\"policy\":\"{}\",\"minimum\":{},\"group_mode\":{},\"threads\":{},\"x\":{:?},\"co_per_group\":{},\"kernel\":{:?},\"stride\":{:?},\"padding\":{:?},\"groups\":{},\"column_elements\":{},\"peak_bytes\":{},\"output_bytes\":{},\"equal\":true,\"samples\":{:?}}}",
                case.name,
                policy.name,
                policy.minimum,
                policy.group_mode,
                rayon::current_num_threads(),
                case.x,
                case.co,
                case.kernel,
                case.stride,
                case.pad,
                case.groups,
                column_elements,
                peaks[i],
                expected.bytes().len(),
                samples[i]
            );
        }
    }
}

fn main() {
    if std::env::var_os("RUN_IN_RAYON").is_some() {
        rayon::scope(|_| measure());
    } else {
        measure();
    }
}
