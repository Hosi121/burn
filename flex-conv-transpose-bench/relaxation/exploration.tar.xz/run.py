#!/usr/bin/env python3
"""Run the policy probe and keep the raw measurements."""
import argparse,json,os,statistics,subprocess
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--threads',type=int,default=4)
p.add_argument('--filter',default='')
p.add_argument('--rounds',type=int,default=7)
p.add_argument('--name',default='screen4')
p.add_argument('--worker',action='store_true')
a=p.parse_args()
root=Path(__file__).resolve().parent
cmd=['taskset','-c',','.join(map(str,range(a.threads))),str(root/'probe'),a.filter,str(a.rounds)]
rows=[]
env={**os.environ,'RAYON_NUM_THREADS':str(a.threads)}
env.pop('RUN_IN_RAYON',None)
if a.worker:env['RUN_IN_RAYON']='1'
with subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,text=True) as child:
 for line in child.stdout:
  row=json.loads(line);row['ms']=statistics.median(row['samples']);row['context']='worker' if a.worker else 'caller';rows.append(row)
  if row['policy']=='current':print(row['case'],flush=True)
 code=child.wait()
 (root/(a.name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
 if code:raise SystemExit(code)
print('Completed',len(rows),'policy results',flush=True)
